package mx.uv.listi.c17349.Saludar;

public class Saludador {
    private String contenido;

    public Saludador(String contenido) {
        this.contenido = contenido;
    }

    public String getContenido() {
        return contenido;
    }
}
