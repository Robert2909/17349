package mx.uv.listi.c17349.Saludar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SaludarApplicationTests {

	@Test
	void contextLoads() {
	}

}
